#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "Auxiliar.h"
#include "Operaciones.h"

int main()
{
    //Declaracion de variables
    char decition, confirmation;
    float number1 = 0; //Igualamos los valores de los numeros a 0 para evitar mostrar la basura guardada
    float number2 = 0;
    float addOutcome, subOutcome, multOutcome, divOutcome, factorOut1, factorOut2;
    do
    {
        system("PAUSE");
        system("CLS"); //Limpiamos pantalla
        //Comienzo del men� de opciones
        printf("\t\t\t\t\tBIENVENIDO A LA CALCULADORA\n");
        printf("\t\t\t\t===========================================");
        printf("\n\t\t\t\t=\t1.Ingresar 1er operando (A=%.2f)  =", number1);
        printf("\n\t\t\t\t=\t2.Ingresar 2do operando (A=%.2f)  =", number2);
        printf("\n\t\t\t\t=\t3.Calcular todas las operaciones  =");
        printf("\n\t\t\t\t=\t4.Informar los resultados         =");
        printf("\n\t\t\t\t=\t5.Salir                           =");
        printf("\n\t\t\t\t===========================================");
        printf("\nQue desea hacer?");
        fflush(stdin);
        scanf("%c", &decition); //Input del menu

        switch(decition)  //Switch para el ingreso a las diferentes opciones
        {

        case '1': //Ingresamos el primer numero
                system("CLS");
                printf("\nIngrese el 1er operando: ");
                number1 = validateFloat(); //Llamada de la funcion "validate float" para asegurarnos que solamente se ingresen numeros
                break;

        case '2'://Ingresamos el segundo numero
                system("CLS");
                printf("\nIngrese el 2do operando: ");
                number2 = validateFloat();//Llamada de la funcion "validate float" para asegurarnos que solamente se ingresen numeros
                break;

        case '3': //En esta opci�n calculamos todas las operaciones
                system("CLS");
                printf("Se estan realizando los calculos....\n");
                //Igualamos las variables a las funciones para guardar su valor de retorno
                addOutcome = add(number1, number2);
                subOutcome = substraction(number1, number2);
                multOutcome = multiplication(number1, number2);
                if(number2 == 0){ //En el caso de que el segundo numero sea 0 igualamos "divOutcome" a 0 usandolo como bandera de estado
                    divOutcome = 0;
                }
                else{
                    divOutcome = divition(number1, number2); //En el caso que los dos n�mero sean correctos se realiza la divisi�n
                }
                factorOut1 = factorial(number1);
                factorOut2 = factorial(number2);
            break;

        case '4': //Mostramos los resultados de las operaciones realizadas
            system("CLS");
            printf("El resultado de %.2f+%.2f es: %.2f", number1, number2, addOutcome);
            printf("\nEl resultado de %.2f-%.2f es: %.2f", number1, number2, subOutcome);
            printf("\nEl resultado de %.2f*%.2f es: %.2f", number1, number2, multOutcome);
            if(divOutcome == 0){ //En caso que el estado de "divOutcome" sea 0, indicando error, mostrando el siguiente mensaje
                printf("\nNo se puede dividir por 0");
            }
            else{
                printf("\nEl resultado de %.2f/%.2f es: %.2f", number1, number2, divOutcome);
            }
            if(factorOut1 <= 0){ //En caso que el n�mero a factorizar sea 0 o menor a 0 mostramos el siguiente mensaje de error
                printf("\nNo se puede realizar el factorial de numeros menores o iguales a 0");
            }
            else{
                printf("\nEl factorial de A es: %.2f", factorOut1);

            }
             if(factorOut2 <= 0){//En caso que el n�mero a factorizar sea 0 o menor a 0 mostramos el siguiente mensaje de error
                printf("\nNo se puede realizar el factorial de numeros menores o iguales a 0");
            }
            else{
                printf("\nEl factorial de B es: %.2f", factorOut2);

            }
            break;

        case '5': //Opcion de salida
            printf("\nEsta seguro que desea salir?\ns-si\nn-no"); //Volvemos a preguntarle una vez m�s al usuario si desea salir
            fflush(stdin);
            scanf("%c", &confirmation);
            break;

        default: //Caso default en caso de no elegir alguna de las 5 opciones
            system("CLS");
            printf("OPCION INVALIDA, VOLVIENDO AL MENU");
            break;
        }

    }
    while(decition!=5 && confirmation != 's'); //Condici�n del bucle, mientras que sea diferente a la opci�n salir y esta no sea confirmada
}
