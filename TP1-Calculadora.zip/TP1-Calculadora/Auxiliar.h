
/** \brief Valida que la entrada por teclado sea numeral
 *
 * \return float El n�mero validado
 *
 */
float validateFloat();


