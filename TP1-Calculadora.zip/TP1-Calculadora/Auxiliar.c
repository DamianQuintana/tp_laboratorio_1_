#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

float validateFloat()
{
    int i, status, lenght;
    char toValidate[20]; //Declaramos un vector de caracteres auxiliar para guardar la entrada del usuario
    float aux; //Declaramos un auxiliar donde vamos a almacenar el valor del retorno

    fflush(stdin); //Limpiamos el buffer de entrada
    gets(toValidate); //Utilizamos la funcion "gets" para guardar lo ingresado por el usuario
    lenght = strlen(toValidate); //Calculamos la longitud de la cadena de caracteres

    do
    {
        for(i=0; i<lenght; i++)
        {
            status = isdigit(toValidate[i]); //El valor de status ser� igual a 0 en caso que detecte un caracter que no sea de tipo num�rico
            if(status <=0 && toValidate[i] != '.' && toValidate[i] !=',') //En caso que el valor no sea v�lido, mostramos el siguiente mensaje de error
            {
                printf("\nNo es un numero, por favor ingrese de nuevo"); //Volvemos a repetir el mismo proceso que hicimos anteriormente para ingresar el valor
                fflush(stdin);
                gets(toValidate);
                lenght = strlen(toValidate);
            }
            if(toValidate[i] == ','){ //En el caso que el valor sea igual a ',', lo cambiamos por un '.', ya que la funci�n "atof" no reconoce el caracter como punto
                toValidate[i] = '.'; //Asignaci�n del nuevo caracter

            }
        }
    }
    while(status == 0); //Este bucle se va a repetir hasta que el valor de "status" sea igual a 0, es decir "No es un caracter num�rico"
    aux = atof(toValidate); //Una vez que lo validamos, tomamos la cadena de caracteres y lo convertimos en flotante dentro de otra variable
    return aux; //Retornamos el valor
}

