/** \brief Toma dos numeros y realiza la suma entre ellos
 *
 * \param Primer numero a sumar
 * \param Segundo numero a sumar
 * \return Resultado de la suma
 *
 */
float add(float number1, float number2);

/** \brief Toma dos numeros y realiza la resta entre ellos
 *
 * \param Primer numero a restar
 * \param Segundo numero a restar
 * \return Resultado de la resta
 *
 */
float substraction(float number1, float number2);

/** \brief Toma dos numeros y realiza la multiplicacion entre ellos
 *
 * \param Primer numero a multiplicar
 * \param Segundo numero a multiplicar
 * \return Resultado de la multiplicacion
 *
 */
float multiplication(float number1, float number2);

/** \brief Toma dos numeros y realiza la division entre ellos
 *
 * \param Primer numero a dividir
 * \param Segundo numero a dividir
 * \return Resultado de la division
 *
 */
float divition(float number1, float number2);

/** \brief Toma un numero y lo factoriza
 *
 * \param Numero a factorizar
 * \return Resultado de la factorizacion
 *
 */
float factorial(float number);

