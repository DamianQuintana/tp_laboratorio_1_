#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

float add(float number1, float number2){ //Funcion que realiza la suma de dos numeros
    float add; //Declaraci�n de variable de resultado
    add = number1+number2; //Operaci�n a realizar almacenandolo en la variable
    return add; //Retorno del valor de la funcion
}
float substraction(float number1, float number2){//Funcion que realiza la resta de dos numeros
    float substraction;//Declaraci�n de variable de resultado
    substraction = number1-number2; //Operaci�n a realizar almacenandolo en la variable
    return substraction;//Retorno del valor de la funcion
}
float multiplication(float number1, float number2){//Funcion que realiza la multiplicacion de dos numeros
    float multiplication;//Declaraci�n de variable de resultado
    multiplication = number1*number2; //Operaci�n a realizar almacenandolo en la variable
    return multiplication;//Retorno del valor de la funcion
}
float divition(float number1, float number2){//Funcion que realiza la division de dos numeros
    float divition;//Declaraci�n de variable de resultado
    divition = number1/number2; //Operaci�n a realizar almacenandolo en la variable
    return divition;//Retorno del valor de la funcion
}

float factorial(float number) // Funcion que realiza la factorizacion del numero
{
    int i; // Declaracion de la variable "i" utilizada en el "for"
    float factorize=1; // Declaracion de la variable donde vamos a guardar el factoreo, la inicializamos en 1

    if( number > 0)
    {
        for(i=1; i<=number; i++) // Bucle para realizar el factoreo
        {
            factorize *= i; // Operaci�n de factorizacion
        }
    }
    else
    {
        factorize = -1;// Numero devuelto en caso de que el numero sea menor a 0, -1 es el numero que nos indica error
    }

    return factorize; //Valor que devuelve la funcion
}

